import React from "react"
import Layout from "../components/layout"
import { Link } from "gatsby"
export default () => (
  <div style={{ color: `blue`, fontSize: `72px` }}>
    <h1>How's the weather today?</h1>
    <p>What a great weather.</p>
  
  
  </div>
)