import React from "react"
import Header from "../components/header"
export default () => (
  <div style={{ color: `green` }}>
    <h1>How\'s the weather today? </h1>
    <p>What a great weather.</p>
  </div>
)
