import React from "react"

import Container from "../components/container"

export default () => (
  <Container>
    <h1>Hello</h1>
    <p>How\'s your day?'</p>
  </Container>
)